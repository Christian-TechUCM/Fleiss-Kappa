from matplotlib._tight_bbox import *  # noqa: F401, F403
from matplotlib import _api
_api.warn_deprecated("3.6", name=__name__, obj_type="module")
